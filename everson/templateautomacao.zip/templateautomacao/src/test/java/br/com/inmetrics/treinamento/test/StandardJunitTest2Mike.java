package br.com.inmetrics.treinamento.test;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import br.com.inemtrics.treinamento.commons.TestBase;
import br.com.inmetrics.treinamento.SingletonInstancePage;
import br.com.inmetrics.treinamento.page.BuscaPrecosEPrazos;
import br.com.inmetrics.treinamento.page.HomePageMike;

public class StandardJunitTest2Mike extends TestBase{
	
	static HomePageMike homemike = new HomePageMike();
	static BuscaPrecosEPrazos buscaPrecosEPrazos = new BuscaPrecosEPrazos();
	
	
	@Before
	public void validarTelaHome() throws Exception {
		SingletonInstancePage.getInstance().getChromeDriver().navigate().to("http://www.correios.com.br/para-voce");
		Assert.assertTrue(homemike.isValida());
		homemike.clicarBotaoPrecosEPrazos();
		Assert.assertTrue(buscaPrecosEPrazos.isValida());
	}
	
	@Test
	public void CalcularEnvioCartaoRegistrada() throws Exception {
		buscaPrecosEPrazos.preencherDataPostagem("24/07/2017");
		Thread.sleep(3000);
		buscaPrecosEPrazos.preencherCepOrigem("06028100");
		Thread.sleep(3000);
		buscaPrecosEPrazos.preencherCepDestino("06028110");
		Thread.sleep(3000);
		buscaPrecosEPrazos.selecionarServico("Carta Registrada");
		Thread.sleep(3000);
		buscaPrecosEPrazos.clicarBotaoEnviar();
		Thread.sleep(3000);
	    buscaPrecosEPrazos.validaSucessoPesquisa();
	
		}

	@Test
	public void CalcularEnvioAerograma() throws Exception {
		buscaPrecosEPrazos.preencherDataPostagem("24/07/2017");
		Thread.sleep(3000);
		buscaPrecosEPrazos.preencherCepOrigem("06028100");
		Thread.sleep(3000);
		buscaPrecosEPrazos.preencherCepDestino("06028110");
		Thread.sleep(3000);
		buscaPrecosEPrazos.selecionarServico("Aerograma");
		Thread.sleep(3000);
		buscaPrecosEPrazos.clicarBotaoEnviar();
		Thread.sleep(3000);
		buscaPrecosEPrazos.validaSucessoPesquisa();
	
   	}

	@Test
	public void CalcularEnvioSedex10() throws Exception {
		buscaPrecosEPrazos.preencherDataPostagem("24/07/2017");
		Thread.sleep(3000);
		buscaPrecosEPrazos.preencherCepOrigem("06028100");
		Thread.sleep(3000);
		buscaPrecosEPrazos.preencherCepDestino("06028110");
		Thread.sleep(3000);
		buscaPrecosEPrazos.selecionarServico("SEDEX 10");
		Thread.sleep(3000);
		buscaPrecosEPrazos.selecionarFormato();
		Thread.sleep(3000);
		buscaPrecosEPrazos.selecionarEmbalagem("Embalagem dos Correios");
		Thread.sleep(3000);
		buscaPrecosEPrazos.selecionarCaixa();
		buscaPrecosEPrazos.selecionarPeso("1");
		Thread.sleep(3000);
		buscaPrecosEPrazos.clicarBotaoEnviar();
		Thread.sleep(3000);
		buscaPrecosEPrazos.validaSucessoPesquisa();
			
    	}

	@Test
	public void CalcularEnvioCartaoViaInternet() throws Exception {
			buscaPrecosEPrazos.preencherDataPostagem("24/07/2017");
			Thread.sleep(3000);
			buscaPrecosEPrazos.preencherCepOrigem("06028100");
			Thread.sleep(3000);
			buscaPrecosEPrazos.preencherCepDestino("06028110");
			Thread.sleep(3000);
			buscaPrecosEPrazos.selecionarServico("Carta Via Internet");
			Thread.sleep(3000);
			buscaPrecosEPrazos.clicarBotaoEnviar();
			Thread.sleep(3000);
			buscaPrecosEPrazos.validaSucessoPesquisa();


    }
	
	@Test
	public void CalcularEnvioeSedex() throws Exception {
		buscaPrecosEPrazos.preencherDataPostagem("24/07/2017");
		Thread.sleep(3000);
		buscaPrecosEPrazos.preencherCepOrigem("06028100");
		Thread.sleep(3000);
		buscaPrecosEPrazos.preencherCepDestino("06028110");
		Thread.sleep(3000);
		buscaPrecosEPrazos.selecionarServico("e-SEDEX");
		Thread.sleep(3000);
		buscaPrecosEPrazos.clicarCheckBoxComparar();
		Thread.sleep(3000);
		buscaPrecosEPrazos.clicarBotaoEnviar();
		Thread.sleep(3000);
		buscaPrecosEPrazos.validaSucessoPesquisa();

	
	
	}
	
}
