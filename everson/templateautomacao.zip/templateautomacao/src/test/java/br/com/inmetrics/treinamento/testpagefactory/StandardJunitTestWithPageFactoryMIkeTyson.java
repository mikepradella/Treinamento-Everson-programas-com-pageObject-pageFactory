package br.com.inmetrics.treinamento.testpagefactory;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
//import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import br.com.inemtrics.treinamento.commons.TestBase;
import br.com.inmetrics.treinamento.SingletonInstancePage;
import br.com.inmetrics.treinamento.pagefactory.BuscaPrecosPrazosageFactoryMiketyson;
//import br.com.inmetrics.treinamento.enumerator.EnumTipoCEP;
import br.com.inmetrics.treinamento.pagefactory.HomePageFactoryMikeTyson;

public class StandardJunitTestWithPageFactoryMIkeTyson extends TestBase{
	
	static HomePageFactoryMikeTyson homeCorreios = new HomePageFactoryMikeTyson();
	static BuscaPrecosPrazosageFactoryMiketyson buscaPrecoPrazo = new BuscaPrecosPrazosageFactoryMiketyson();
	static WebDriver driver = SingletonInstancePage.getInstance().getChromeDriver();
	
	@Before
	public void validarTelaHome() throws Exception {
		driver.navigate().to("http://www.correios.com.br/para-voce");
		
		PageFactory.initElements(driver, homeCorreios);
		PageFactory.initElements(driver, buscaPrecoPrazo);
		
		Assert.assertTrue(homeCorreios.isValida());
		Thread.sleep(3000);
				homeCorreios.clicarBuscaPrecosPrazos();
		Thread.sleep(3000);		
 		Assert.assertTrue(buscaPrecoPrazo.isValida());
	}

	@Test
	public void  CalcularEnvioCartaoRegistrada()throws Exception{
		buscaPrecoPrazo.preencherDataPostagem("27/07/2017");
		Thread.sleep(3000);
		buscaPrecoPrazo.preencherCepOrigem("06028100");
		Thread.sleep(3000);
		buscaPrecoPrazo.preencherCepDestino("06028110");
		Thread.sleep(3000);
		buscaPrecoPrazo.selecionarServico("10014");
		Thread.sleep(3000);
		buscaPrecoPrazo.clicarEnviar();
		Thread.sleep(3000);
		buscaPrecoPrazo.validaSucessoPesquisa();
	}
	
	@Test
	public void CalcularEnvioAerograma() throws Exception {
		buscaPrecoPrazo.preencherDataPostagem("27/07/2017");
		Thread.sleep(3000);
		buscaPrecoPrazo.preencherCepOrigem("06028100");
		Thread.sleep(3000);
		buscaPrecoPrazo.preencherCepDestino("06028110");
		Thread.sleep(3000);
		buscaPrecoPrazo.selecionarServico("85480");
		Thread.sleep(3000);
		buscaPrecoPrazo.clicarEnviar();
		Thread.sleep(3000);
		buscaPrecoPrazo.validaSucessoPesquisa();
	
	
	}
	
	@Test
	public void CalcularEnvioSedex10() throws Exception {
			
		buscaPrecoPrazo.preencherDataPostagem("27/07/2017");
		Thread.sleep(3000);
		buscaPrecoPrazo.preencherCepOrigem("06028100");
		Thread.sleep(3000);
		buscaPrecoPrazo.preencherCepDestino("06028110");
		Thread.sleep(3000);
		buscaPrecoPrazo.selecionarServico("40215");
		Thread.sleep(3000);
		buscaPrecoPrazo.selecionarFormato();
		Thread.sleep(3000);
		buscaPrecoPrazo.selecionarEmbalagem("correiosEmbalagem1");
		Thread.sleep(3000);
		buscaPrecoPrazo.selecionarCaixa();
		Thread.sleep(3000);
		buscaPrecoPrazo.selecionarPeso("1");
		Thread.sleep(3000);
		buscaPrecoPrazo.clicarEnviar();
		Thread.sleep(3000);
		buscaPrecoPrazo.validaSucessoPesquisa();
	
    	}


	@Test
	public void CalcularEnvioCartaoViaInternet() throws Exception {
		buscaPrecoPrazo.preencherDataPostagem("27/07/2017");
		Thread.sleep(3000);
		buscaPrecoPrazo.preencherCepOrigem("06028100");
		Thread.sleep(3000);
		buscaPrecoPrazo.preencherCepDestino("06028110");
		Thread.sleep(3000);
		buscaPrecoPrazo.selecionarServico("68233");
		Thread.sleep(3000);
		buscaPrecoPrazo.clicarEnviar();
		Thread.sleep(3000);
		buscaPrecoPrazo.validaSucessoPesquisa();
	
	
	}
	

	@Test
	public void CalcularEnvioeSedex() throws Exception {
		buscaPrecoPrazo.preencherDataPostagem("27/07/2017");
		Thread.sleep(3000);
		buscaPrecoPrazo.preencherCepOrigem("06028100");
		Thread.sleep(3000);
		buscaPrecoPrazo.preencherCepDestino("06028110");
		Thread.sleep(3000);
		buscaPrecoPrazo.selecionarServico("81019");
		Thread.sleep(3000);
		buscaPrecoPrazo.clicarEnviar();
		Thread.sleep(3000);
		buscaPrecoPrazo.validaSucessoPesquisa();
	
	
	}
}
