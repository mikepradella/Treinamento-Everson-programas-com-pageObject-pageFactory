package br.com.inmetrics.treinamento.page;

import org.openqa.selenium.WebElement;

import br.com.inmetrics.treinamento.SingletonInstancePage;

public class BuscaPrecosEPrazos extends BasePage{
	
private String dataPostagem = "data";
private String titulaPaginaPrecosPrazos = "/html/body/div[1]/div[3]/div[2]/div/div/div[2]/div[2]/div[1]/h3";
private String cepOrigem = "cepOrigem";
private String cepDestino = "cepDestino";
private String tipoServico = "servico";
private String botaoEnviarPrecosPrazos = "//*[@id='spanBotao']/input";
private String textoSucessoPesquisa = "Resultado do C�lculo";
private String xpathElementoTituloResultadoPesquisa = "/html/body/div[1]/div[3]/div[2]/div/div/div[2]/div[2]/div[1]/h3";
private String xpathElementoFormato = "//*[@id='spanFormato']/img[1]";
private String tipoEmbalagem = "embalagem1";
private String tipoPeso= "peso";
private String tipoSelecionaCaixa = "//*[@id='spanTipoEmbalagem']/div/div[2]/div/div[1]/div/p/button";
private String checkCompararTodos= "//*[@id='spanCompararServicos']/span/label/input";




public boolean isValida() throws Exception {
	return contemElementoByXPath(titulaPaginaPrecosPrazos);
}


public void preencherDataPostagem(String texto){
	WebElement elemento = SingletonInstancePage.getInstance().getChromeDriver().findElementByName(dataPostagem);
	preencherTexto(texto, elemento);
	
}

public void preencherCepOrigem(String texto){
	WebElement elemento = SingletonInstancePage.getInstance().getChromeDriver().findElementByName(cepOrigem);
	preencherTexto(texto, elemento);
	
}


public void preencherCepDestino(String texto){
	WebElement elemento = SingletonInstancePage.getInstance().getChromeDriver().findElementByName(cepDestino);
	preencherTexto(texto, elemento);
	
}


public void selecionarServico(String texto){
	selecionarElementoListBoxByText(tipoServico,texto);
	
}

public void clicarBotaoEnviar() {
	clicarPorXPath(botaoEnviarPrecosPrazos);
}

public void selecionarFormato(){
	clicarPorXPath(xpathElementoFormato);
	
}


public void selecionarEmbalagem(String texto){
	selecionarElementoListBoxByText(tipoEmbalagem,texto);
}



public void selecionarPeso(String texto){
	selecionarElementoListBoxByText(tipoPeso,texto);
}

public void selecionarCaixa() {
	clicarPorXPath(tipoSelecionaCaixa);
	
}

public void clicarCheckBoxComparar() {
	clicarPorXPath(checkCompararTodos);
}


public boolean validaSucessoPesquisa() throws Exception {
	return elementoContemTextoByXPath(xpathElementoTituloResultadoPesquisa, textoSucessoPesquisa);
}




}
