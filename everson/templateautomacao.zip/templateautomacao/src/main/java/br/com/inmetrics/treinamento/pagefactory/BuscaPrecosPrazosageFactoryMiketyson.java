package br.com.inmetrics.treinamento.pagefactory ;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import br.com.inmetrics.treinamento.enumerator.EnumTipoServico;

public class BuscaPrecosPrazosageFactoryMiketyson extends BasePageFactory{

	@FindBy(name = "data")
	private WebElement campoDataPostagem;
	
	@FindBy(name = "cepOrigem")
	private WebElement campCepOrigem;
	
	@FindBy(name= "cepDestino")
	private WebElement campoCepDestino;
	
	@FindBy(xpath = "/html/body/div[1]/div[3]/div[2]/div/div/div[2]/div[2]/div[3]/form/div/div/span[7]/label/select")
	private WebElement campoTipoServico;
	
	@FindBy(name= "Calcular")
	private WebElement campoEnviar;
	
	@FindBy(xpath = "/html/body/div[1]/div[3]/div[2]/div/div/div[2]/div[2]/div[1]/h3")
	private WebElement xpathElementoTituloPrecosPrazos;
	
	
	@FindBy(xpath = "/html/body/div[1]/div[3]/div[2]/div/div/div[2]/div[2]/div[1]/h3")
	private WebElement xpathElementoTituloResultadoPesquisa;
	
	@FindBy(name = "embalagem1")
	private WebElement tipoEmbalagem ;
	
	@FindBy(xpath = "//*[@id='spanTipoEmbalagem']/div/div[2]/div/div[1]/div/p/button")
	private WebElement tipoSelecionaCaixa;

	@FindBy(name = "peso")
	private WebElement tipoPeso;
	
	@FindBy(xpath = "//*[@id='spanFormato']/img[1]")
	private WebElement xpathElementoFormato ;
	
	
	@FindBy(name = "compararServico")
	private WebElement checkBoxComparar;
	
	
	private String textoSucessoPesquisa = "Resultado do C�lculo";
	
	
	public boolean isValida() throws Exception {
		return contemElemento(xpathElementoTituloPrecosPrazos);
	}

	public void preencherDataPostagem(String texto) {
		preencherTexto(texto, campoDataPostagem);
	}
	
	public void preencherCepOrigem(String texto) {
		preencherTexto(texto, campCepOrigem);
	}

	

	public void preencherCepDestino(String texto) {
		preencherTexto(texto, campoCepDestino);
		
	}
	
	public void selecionarServico(String texto) {
		selecionarElementoListBoxByName(campoTipoServico, texto);
		
	}
	
	
	public void clicarEnviar() {
		clicar(campoEnviar);
	}

	public boolean validaSucessoPesquisa() throws Exception {
		return elementoContemTexto(xpathElementoTituloResultadoPesquisa, textoSucessoPesquisa);
	}



	public void selecionarEmbalagem(String texto){
		selecionarElementoListBoxByName(tipoEmbalagem,texto);
	}
	
	public void selecionarCaixa() {
		clicarPorXPath(tipoSelecionaCaixa);
		
	}


	public void selecionarPeso(String texto){
		selecionarElementoListBoxByName(tipoPeso,texto);
	}


	public void selecionarFormato(){
		clicarPorXPath(xpathElementoFormato);
	
	}
	

	public void clicarCheckBoxComparar() {
		clicarPorXPath(checkBoxComparar);
	}



	
//	public void selecionarFiltro(String string) {
//		selecionarElementoListBoxByName(campoTipoServico, EnumTipoServico.AEROGRAMA.getValue());
//	}
//	
	
}
