package br.com.inmetrics.treinamento.pagefactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import br.com.inmetrics.treinamento.SingletonInstancePage;

public class HomePageFactoryMikeTyson extends BasePageFactory{

//	@FindBy(id = "portaltab-para-voce")
	@FindBy(id = "portaltab-para-voce")
	private WebElement botao_voce_mike; 
	
	@FindBy(xpath = "//*[@id='content-principais-servicos']/ul/li[3]/a/img")
	private WebElement XPATH_BUTTON_PRECOS_PRAZOS;
	
	
	public void goToHome() {
		SingletonInstancePage.getInstance().getChromeDriver().navigate().to("http://www.correios.com.br/para-voce");
	}

	/**
	 * Valida se os componentes de validação da tela estão presentes
	 * @return
	 * @throws Exception 
	 */
	public boolean isValida() throws Exception {
		return contemElemento(botao_voce_mike);
	}
	
	public void clicarBuscaPrecosPrazos() {
		clicar(XPATH_BUTTON_PRECOS_PRAZOS);
	}

	
	
}
