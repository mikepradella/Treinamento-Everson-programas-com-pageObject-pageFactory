package br.com.inmetrics.treinamento.enumerator;

public enum EnumTipoServico {
	
	AEROGRAMA("85480");

	
	
	
	
	
	
	private final String value;
	
	EnumTipoServico(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}
}
