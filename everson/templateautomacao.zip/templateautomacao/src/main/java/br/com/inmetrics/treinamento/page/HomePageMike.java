package br.com.inmetrics.treinamento.page;

import br.com.inmetrics.treinamento.SingletonInstancePage;

public class HomePageMike extends BasePage{
	

	private String ABA_VOCE = "portaltab-para-voce"; 
	private String XPATH_BUTTON_PRECOS_PRAZOS = ("//*[@id='content-principais-servicos']/ul/li[3]/a/img");
	
	

//	public void goToHome() {
//		SingletonInstancePage.getInstance().getChromeDriver().navigate().to("http://www.correios.com.br/para-voce");
//	}
	
	/**
	 * Valida se os componentes de validacao�o da tela estao presentes
	 * @return
	 * @throws Exception 
	 */
	public boolean isValida() throws Exception {
		return contemElementoById(ABA_VOCE);
	}
	
	public void clicarBotaoPrecosEPrazos() {
		clicarPorXPath(XPATH_BUTTON_PRECOS_PRAZOS);
	}
}
